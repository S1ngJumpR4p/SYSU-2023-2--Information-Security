文件树如下：
21307082赖耿桂信息安全技术project
├─ 21307082赖耿桂信息安全技术project.pdf
├─ Code
│    ├─ DES.py
│    ├─ Tables.py
│    ├─ test.txt
│    └─ test_encrypted.txt
└─ readme.md

21307082赖耿桂信息安全技术project.pdf：实验报告
Code文件夹：存放代码以及测试用例
readme.txt：本文件

运行方式：在Code目录下运行DES.py，按照要求进行输入即可。